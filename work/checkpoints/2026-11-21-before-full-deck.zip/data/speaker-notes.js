// Presenter notes will be added when supplied with the later slide content.
export const speakerNotes = {};
